import React, { useState, useEffect } from 'react';
import { UserProfile, CallLog, ChatMessage, BlacklistedUser } from '../types/tawasol';
import { LogoBadge } from './LogoBadge';
import {
  Lock,
  ShieldCheck,
  Users,
  MessageSquare,
  PhoneCall,
  Mic,
  Video,
  Radio,
  Send,
  Trash2,
  X,
  Eye,
  EyeOff,
  Ban,
  CheckCircle,
  Activity,
  Download,
  UserX,
  UserCheck,
  AlertOctagon,
  FolderArchive,
  Package,
  FileCode,
  Copy,
  Check,
} from 'lucide-react';

interface AdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  onBroadcastMessage?: (title: string, message: string) => void;
  allUsers: UserProfile[];
  allMessages: ChatMessage[];
  allCalls: CallLog[];
  onUserDeletedPermanently?: (number: string) => void;
  onClearUserChat?: (number: string) => void;
}

export const AdminModal: React.FC<AdminModalProps> = ({
  isOpen,
  onClose,
  onBroadcastMessage,
  allUsers,
  allMessages,
  allCalls,
  onUserDeletedPermanently,
  onClearUserChat,
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'kodular' | 'stats' | 'users' | 'blacklist' | 'messages' | 'calls' | 'broadcast' | 'control'>('kodular');
  const [blacklist, setBlacklist] = useState<BlacklistedUser[]>([]);
  const [downloadingFile, setDownloadingFile] = useState<string | null>(null);
  const [copySuccess, setCopySuccess] = useState(false);

  // Broadcast state
  const [broadcastTitle, setBroadcastTitle] = useState('تنبيه هام من إدارة تواصل 24');
  const [broadcastBody, setBroadcastBody] = useState('');
  const [broadcastSuccess, setBroadcastSuccess] = useState(false);

  // Users local state
  const [userList, setUserList] = useState<UserProfile[]>(allUsers);

  useEffect(() => {
    setUserList(allUsers);
  }, [allUsers]);

  const fetchAdminStats = async () => {
    try {
      const res = await fetch('/api/admin/stats', {
        headers: { Authorization: 'Bearer admin_auth_faroog77_token' },
      });
      const data = await res.json();
      if (data.users) setUserList(data.users);
      if (data.blacklist) setBlacklist(data.blacklist);
    } catch {
      // Local fallback
    }
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Prompt requested exact password: fa&roog#77
    if (password === 'fa&roog#77') {
      setIsAuthenticated(true);
      setAuthError(null);
      fetchAdminStats();
    } else {
      setAuthError('كلمة المرور غير صحيحة. هذه النافذة مخصصة لمالك التطبيق فقط.');
    }
  };

  // Permanent Delete & Forbid Return
  const handlePermanentDelete = async (number: string, userName: string) => {
    const confirmDelete = window.confirm(
      `هل أنت متأكد من مسح المستخدم "${userName}" (${number}) نهائياً من القائمة وحظر رقمه من العودة مرة أخرى دون إذنك؟`
    );
    if (!confirmDelete) return;

    setUserList((prev) => prev.filter((u) => u.number !== number));
    setBlacklist((prev) => [
      ...prev,
      {
        number,
        name: userName,
        bannedAt: Date.now(),
        reason: 'تم مسحه وحظر رقمه نهائياً من قبل مالك التطبيق',
      },
    ]);

    if (onUserDeletedPermanently) {
      onUserDeletedPermanently(number);
    }

    try {
      await fetch('/api/admin/permanent-delete', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer admin_auth_faroog77_token',
        },
        body: JSON.stringify({ number, reason: 'تم مسحه وحظر رقمه نهائياً من قبل مالك التطبيق' }),
      });
    } catch {
      // Local fallback
    }
  };

  // Restore Permission to Return
  const handleRestorePermission = async (number: string) => {
    setBlacklist((prev) => prev.filter((b) => b.number !== number));

    try {
      await fetch('/api/admin/restore-permission', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer admin_auth_faroog77_token',
        },
        body: JSON.stringify({ number }),
      });
    } catch {
      // Local fallback
    }
  };

  const handleSendBroadcast = async () => {
    if (!broadcastBody.trim()) return;
    try {
      if (onBroadcastMessage) {
        onBroadcastMessage(broadcastTitle, broadcastBody);
      }
      // Also notify backend
      await fetch('/api/admin/broadcast', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer admin_auth_faroog77_token',
        },
        body: JSON.stringify({ title: broadcastTitle, message: broadcastBody }),
      });
      setBroadcastSuccess(true);
      setBroadcastBody('');
      setTimeout(() => setBroadcastSuccess(false), 3000);
    } catch (err) {
      console.warn('Broadcast error:', err);
    }
  };

  // Clear subscriber chat messages (Admin action)
  const handleClearUserChat = async (targetNumber: string, userName: string) => {
    const confirmClear = window.confirm(
      `هل أنت متأكد من حذف ومسح جميع محادثات ورسائل المشترك "${userName}" (${targetNumber}) نهائياً؟`
    );
    if (!confirmClear) return;

    if (onClearUserChat) {
      onClearUserChat(targetNumber);
    }

    try {
      const res = await fetch('/api/admin/clear-user-chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer admin_auth_faroog77_token',
        },
        body: JSON.stringify({ targetNumber }),
      });
      const data = await res.json();
      if (data.success) {
        alert(`تم حذف جميع محادثات ورسائل المشترك (${targetNumber}) بنجاح.`);
      }
    } catch {
      // Handled locally
    }
  };

  const handleToggleBan = async (number: string, currentBan: boolean) => {
    const updated = userList.map((u) => (u.number === number ? { ...u, isBanned: !currentBan } : u));
    setUserList(updated);

    try {
      await fetch('/api/admin/toggle-ban', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer admin_auth_faroog77_token',
        },
        body: JSON.stringify({ number, ban: !currentBan }),
      });
    } catch {
      // Local fallback
    }
  };

  const handleExportData = () => {
    const dump = {
      exportedAt: new Date().toISOString(),
      users: userList,
      messages: allMessages,
      calls: allCalls,
    };
    const blob = new Blob([JSON.stringify(dump, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tawasol24_audit_report_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadFile = async (url: string, filename: string) => {
    setDownloadingFile(filename);
    try {
      const response = await fetch(url);
      if (!response.ok) throw new Error('Fetch failed');
      const blob = await response.blob();
      const blobUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(blobUrl);
    } catch {
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } finally {
      setTimeout(() => setDownloadingFile(null), 1500);
    }
  };

  const handleCopyKodularCode = async () => {
    try {
      const res = await fetch('/index-standalone-kodular.html');
      let text = '';
      if (res.ok) {
        text = await res.text();
      } else {
        text = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" />
  <title>تواصل 24 - Tawasol 24</title>
  <meta name="theme-color" content="#0f172a" />
</head>
<body style="margin:0;padding:0;background:#0f172a;overflow:hidden;">
  <iframe src="${window.location.origin}" style="width:100vw;height:100vh;border:none;" allow="camera; microphone; display-capture; autoplay; clipboard-write; clipboard-read"></iframe>
</body>
</html>`;
      }
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(text);
        setCopySuccess(true);
        setTimeout(() => setCopySuccess(false), 2500);
      }
    } catch {
      // fallback
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden text-right text-slate-100 my-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-3">
            <LogoBadge size="sm" showText={false} />
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-bold text-white">لوحة تحكم مالك التطبيق - إدارة تواصل 24</h3>
                <span className="px-2 py-0.5 rounded-md bg-blue-500/10 border border-blue-500/30 text-blue-400 text-[10px] font-mono">
                  Super Admin
                </span>
              </div>
              <p className="text-xs text-slate-400">إشراف شامل على المنظومة والعمليات والإحصائيات</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        {!isAuthenticated ? (
          /* Password Authentication Gate */
          <div className="p-8 sm:p-12 flex flex-col items-center justify-center max-w-md mx-auto text-center">
            <div className="w-16 h-16 rounded-3xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400 mb-5 shadow-lg shadow-blue-500/10">
              <Lock className="w-8 h-8" />
            </div>

            <h4 className="text-xl font-bold text-white mb-2">منطقة محمية لمالك التطبيق</h4>
            <p className="text-xs text-slate-400 mb-6 leading-relaxed">
              وفق المواصفات، هذه النافذة مشفرة ومخصصة لمالك التطبيق فقط ولا يمكن فتحها لأي مستخدم آخر.
            </p>

            <form onSubmit={handleLogin} className="w-full space-y-4">
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="أدخل كلمة المرور الخاصة بالإدارة..."
                  dir="ltr"
                  className="w-full px-4 py-3 bg-slate-800/90 border border-slate-700 rounded-xl text-center font-mono text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute left-3 top-3.5 text-slate-400 hover:text-slate-200"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>

              {authError && (
                <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
                  {authError}
                </div>
              )}

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-lg shadow-blue-600/30 transition active:scale-[0.99] flex items-center justify-center gap-1.5"
              >
                <ShieldCheck className="w-4 h-4" />
                الدخول إلى لوحة التحكم
              </button>
            </form>
          </div>
        ) : (
          /* Authenticated Dashboard */
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Sub Nav Navigation - Smooth horizontal scroll right and left */}
            <div
              className="flex items-center gap-1 px-4 py-2 border-b border-slate-800 bg-slate-900/50 overflow-x-auto touch-pan-x no-scrollbar scroll-smooth text-xs font-medium"
              onWheel={(e) => {
                e.currentTarget.scrollLeft += e.deltaY;
              }}
              style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
            >
              {[
                { id: 'kodular', label: 'حزمة كوديلار والبناء 📦', icon: FolderArchive },
                { id: 'stats', label: 'الإحصائيات المباشرة', icon: Activity },
                { id: 'users', label: `المستخدمون (${userList.length})`, icon: Users },
                { id: 'blacklist', label: `المطرودون نهائياً (${blacklist.length})`, icon: UserX },
                { id: 'messages', label: 'سجل الرسائل والوسائط', icon: MessageSquare },
                { id: 'calls', label: 'سجل المكالمات', icon: PhoneCall },
                { id: 'broadcast', label: 'بث إشعار عام', icon: Radio },
                { id: 'control', label: 'النسخ الاحتياطي والضبط', icon: ShieldCheck },
              ].map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`px-3 py-2 rounded-xl whitespace-nowrap shrink-0 flex items-center gap-1.5 transition ${
                      activeTab === tab.id
                        ? 'bg-blue-600 text-white font-bold shadow-md shadow-blue-600/20'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Tab Contents */}
            <div className="flex-1 overflow-y-auto p-5 space-y-6">
              {/* Tab 0: Kodular & Build Packages (مجلد وحزمة بناء التطبيق لمنصة كوديلار) */}
              {activeTab === 'kodular' && (
                <div className="space-y-6 max-w-3xl">
                  {/* Top Alert Banner */}
                  <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-blue-900/40 via-indigo-900/30 to-purple-900/30 border border-blue-500/40 flex items-start gap-3.5 shadow-xl">
                    <div className="p-3 rounded-2xl bg-blue-500/20 text-blue-400 shrink-0 border border-blue-500/30">
                      <FolderArchive className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-bold text-white text-base mb-1 flex items-center gap-2">
                        <span>مجلد وحزمة بناء التطبيق لمنصة كوديلار (Kodular APK Build Package)</span>
                        <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold">
                          غرفة الإدارة
                        </span>
                      </h4>
                      <p className="text-xs text-slate-300 leading-relaxed">
                        تم تنزيل وتثبيت المجلد وحزم البناء هنا داخل غرفة الإدارة لتتمكن من تحميلها مباشرة إلى هاتفك أو حاسوبك بنقرة واحدة، واستخدامها في منصة كوديلار لتوليد ملف الـ APK.
                      </p>
                    </div>
                  </div>

                  {/* Grid of Downloadable Packages */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Card 1: kodular-standalone.zip */}
                    <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/80 hover:border-emerald-500/50 transition flex flex-col justify-between space-y-3 shadow-lg">
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/30">
                            موصى به لكوديلار 🚀
                          </span>
                          <span className="text-[11px] text-slate-400 font-mono">130 KB (خفيف جداً)</span>
                        </div>
                        <h5 className="font-bold text-white text-sm flex items-center gap-2">
                          <Package className="w-4 h-4 text-emerald-400" />
                          المجلد المضغوط المخصص لكوديلار
                        </h5>
                        <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                          ملف <strong className="text-slate-200">kodular-standalone.zip</strong> يحتوي على ملف <code className="text-emerald-300">index.html</code> المدمج الكامل لكافة أكواد الواجهة والتصميم والسكربتات.
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleDownloadFile('/downloads/kodular-standalone.zip', 'kodular-standalone.zip')}
                        disabled={downloadingFile === 'kodular-standalone.zip'}
                        className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 transition active:scale-[0.99] cursor-pointer"
                      >
                        <Download className="w-4 h-4" />
                        <span>
                          {downloadingFile === 'kodular-standalone.zip' ? 'جاري التحميل...' : 'تنزيل kodular-standalone.zip'}
                        </span>
                      </button>
                    </div>

                    {/* Card 2: index.html standalone */}
                    <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/80 hover:border-blue-500/50 transition flex flex-col justify-between space-y-3 shadow-lg">
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="px-2.5 py-0.5 rounded-full bg-blue-500/20 text-blue-300 text-[10px] font-bold border border-blue-500/30">
                            ملف واحد مستقل (بدون فك ضغط)
                          </span>
                          <span className="text-[11px] text-slate-400 font-mono">524 KB</span>
                        </div>
                        <h5 className="font-bold text-white text-sm flex items-center gap-2">
                          <FileCode className="w-4 h-4 text-blue-400" />
                          ملف index.html المستقل المدمج
                        </h5>
                        <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                          ملف واحد يحتوي بداخله كافة مكتبات React و Tailwind CSS. ارفعه مباشرة في أصول Kodular دون الحاجة لفك ضغط أي ملف!
                        </p>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleDownloadFile('/index-standalone-kodular.html', 'index.html')}
                          disabled={downloadingFile === 'index.html'}
                          className="flex-1 py-3 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-blue-600/20 transition active:scale-[0.99] cursor-pointer"
                        >
                          <Download className="w-4 h-4" />
                          <span>{downloadingFile === 'index.html' ? 'جاري التحميل...' : 'تنزيل index.html'}</span>
                        </button>
                        <button
                          type="button"
                          onClick={handleCopyKodularCode}
                          className="py-3 px-3.5 rounded-xl bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer"
                          title="نسخ الكود بالكامل للحافظة"
                        >
                          {copySuccess ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                          <span>{copySuccess ? 'تم النسخ!' : 'نسخ الكود'}</span>
                        </button>
                      </div>
                    </div>

                    {/* Card 3: tawasol24-build.zip */}
                    <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/80 hover:border-purple-500/50 transition flex flex-col justify-between space-y-3 shadow-lg">
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="px-2.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 text-[10px] font-bold border border-purple-500/30">
                            حزمة البناء الكاملة (dist)
                          </span>
                          <span className="text-[11px] text-slate-400 font-mono">1.7 MB</span>
                        </div>
                        <h5 className="font-bold text-white text-sm flex items-center gap-2">
                          <FolderArchive className="w-4 h-4 text-purple-400" />
                          حزمة tawasol24-build.zip
                        </h5>
                        <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                          المجلد المضغوط الشامل لبناء الإنتاج المترجم، يحتوي على مجلد <code className="text-purple-300">assets/</code> مع كافة صور وشعارات وأيقونات المنصة.
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleDownloadFile('/downloads/tawasol24-build.zip', 'tawasol24-build.zip')}
                        disabled={downloadingFile === 'tawasol24-build.zip'}
                        className="w-full py-3 px-4 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-purple-600/20 transition active:scale-[0.99] cursor-pointer"
                      >
                        <Download className="w-4 h-4" />
                        <span>
                          {downloadingFile === 'tawasol24-build.zip' ? 'جاري التحميل...' : 'تنزيل tawasol24-build.zip'}
                        </span>
                      </button>
                    </div>

                    {/* Card 4: Complete Source + Guide */}
                    <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/80 hover:border-indigo-500/50 transition flex flex-col justify-between space-y-3 shadow-lg">
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 text-[10px] font-bold border border-indigo-500/30">
                            الشاملة + السورس كود
                          </span>
                          <span className="text-[11px] text-slate-400 font-mono">4.8 MB</span>
                        </div>
                        <h5 className="font-bold text-white text-sm flex items-center gap-2">
                          <Package className="w-4 h-4 text-indigo-400" />
                          حزمة المشروع الكاملة مع الدليل
                        </h5>
                        <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                          يحتوي على الكود المصدري الكامل وخادم الـ WebSockets ودليل إنشاء وتصدير تطبيق الأندرويد خطوة بخطوة.
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleDownloadFile('/downloads/tawasol24-complete-package.zip', 'tawasol24-complete-package.zip')}
                        disabled={downloadingFile === 'tawasol24-complete-package.zip'}
                        className="w-full py-3 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/20 transition active:scale-[0.99] cursor-pointer"
                      >
                        <Download className="w-4 h-4" />
                        <span>
                          {downloadingFile === 'tawasol24-complete-package.zip' ? 'جاري التحميل...' : 'تنزيل الحزمة الشاملة'}
                        </span>
                      </button>
                    </div>
                  </div>

                  {/* Instructions Box for Kodular */}
                  <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
                    <h5 className="font-bold text-xs text-blue-400 flex items-center gap-2">
                      <span>📱 خطوات تشغيل الملف في منصة كوديلار (Kodular) في دقيقة واحدة:</span>
                    </h5>
                    <ol className="text-xs text-slate-300 space-y-2 list-decimal list-inside pr-1 leading-relaxed">
                      <li>
                        اضغط على زر <strong className="text-white">«تنزيل index.html»</strong> أو <strong className="text-white">«تنزيل kodular-standalone.zip»</strong> أعلاه لحفظه بجهازك.
                      </li>
                      <li>
                        افتح مشروعك في منصة <strong className="text-white">Kodular</strong> واذهب إلى قسم الأصول (<strong className="text-white">Assets</strong>) وارفع ملف <code className="text-emerald-400 font-mono">index.html</code>.
                      </li>
                      <li>
                        في شاشة التصميم (Designer)، اسحب عنصر <strong className="text-white">Web_Viewer</strong> واجعل العرض (<strong className="text-white">Width</strong>) والارتفاع (<strong className="text-white">Height</strong>) بقيمة <strong className="text-blue-300">Fill Parent</strong>.
                      </li>
                      <li>
                        في حقل الرابط (<strong className="text-white">HomeURL</strong>) الخاص بـ Web_Viewer، اكتب بالضبط:
                        <div className="my-1.5 p-2 rounded-xl bg-slate-950 border border-slate-800 font-mono text-emerald-400 text-center text-xs select-all">
                          file:///android_asset/index.html
                        </div>
                      </li>
                      <li>
                        في شريط القوائم العلوي بـ Kodular: اضغط على <strong className="text-white">Export</strong> ثم <strong className="text-white">Android App (.apk)</strong> ومبروك عليك التطبيق!
                      </li>
                    </ol>
                  </div>
                </div>
              )}

              {/* Tab 1: Stats */}
              {activeTab === 'stats' && (
                <div className="space-y-6">
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
                    <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-800">
                      <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
                        <span>المستخدمون المسجلون</span>
                        <Users className="w-4 h-4 text-blue-400" />
                      </div>
                      <div className="text-2xl font-bold font-mono text-white">{userList.length}</div>
                      <span className="text-[10px] text-emerald-400 font-medium">
                        {userList.filter((u) => u.isOnline).length} متصل حالياً
                      </span>
                    </div>

                    <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-800">
                      <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
                        <span>إجمالي الرسائل</span>
                        <MessageSquare className="w-4 h-4 text-emerald-400" />
                      </div>
                      <div className="text-2xl font-bold font-mono text-white">{allMessages.length}</div>
                      <span className="text-[10px] text-slate-400">تراكمي</span>
                    </div>

                    <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-800">
                      <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
                        <span>الرسائل الصوتية</span>
                        <Mic className="w-4 h-4 text-purple-400" />
                      </div>
                      <div className="text-2xl font-bold font-mono text-white">
                        {allMessages.filter((m) => m.contentType === 'audio').length}
                      </div>
                      <span className="text-[10px] text-purple-400">تسجيلات فورية</span>
                    </div>

                    <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-800">
                      <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
                        <span>الفيديوهات والصور</span>
                        <Video className="w-4 h-4 text-amber-400" />
                      </div>
                      <div className="text-2xl font-bold font-mono text-white">
                        {allMessages.filter((m) => m.contentType === 'video' || m.contentType === 'image').length}
                      </div>
                      <span className="text-[10px] text-amber-400">وسائط متعددة</span>
                    </div>

                    <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-800">
                      <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
                        <span>المكالمات الصوتية</span>
                        <PhoneCall className="w-4 h-4 text-cyan-400" />
                      </div>
                      <div className="text-2xl font-bold font-mono text-white">{allCalls.length}</div>
                      <span className="text-[10px] text-cyan-400">مكالمات مسجلة</span>
                    </div>

                    <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-800">
                      <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
                        <span>المطرودون نهائياً</span>
                        <UserX className="w-4 h-4 text-rose-400" />
                      </div>
                      <div className="text-2xl font-bold font-mono text-white">
                        {blacklist.length}
                      </div>
                      <span className="text-[10px] text-rose-400">ممنوعون من العودة</span>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-blue-950/20 border border-blue-900/30 text-xs text-blue-300 leading-relaxed">
                    💡 <span className="font-semibold">صلاحيات المالك:</span> يمكنك مسح أي مستخدم نهائياً من القائمة بحيث يفقد القدرة على العودة أو التسجيل مرة أخرى دون إذنك.
                  </div>
                </div>
              )}

              {/* Tab 2: Users Table */}
              {activeTab === 'users' && (
                <div className="space-y-4">
                  <div className="overflow-x-auto rounded-2xl border border-slate-800">
                    <table className="w-full text-right text-xs">
                      <thead className="bg-slate-800/70 text-slate-400 border-b border-slate-800">
                        <tr>
                          <th className="p-3">المستخدم</th>
                          <th className="p-3">رقم تواصل 24</th>
                          <th className="p-3">الحالة</th>
                          <th className="p-3">تاريخ التسجيل</th>
                          <th className="p-3 text-center">الإجراءات</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800">
                        {userList.map((user) => (
                          <tr key={user.number} className="hover:bg-slate-800/30 transition">
                            <td className="p-3 flex items-center gap-2.5">
                              <img
                                src={user.avatar || '/src/assets/images/tawasol24_logo_badge_1791830208691.jpg'}
                                alt={user.name}
                                className="w-8 h-8 rounded-full object-cover ring-1 ring-slate-700"
                              />
                              <div>
                                <span className="font-semibold text-white block">{user.name}</span>
                                <span className="text-[10px] text-slate-400 truncate max-w-[140px] block">
                                  {user.statusMessage || '-'}
                                </span>
                              </div>
                            </td>
                            <td className="p-3 font-mono text-blue-400 font-bold">{user.number}</td>
                            <td className="p-3">
                              {user.isBanned ? (
                                <span className="text-rose-400 font-medium">محظور مؤقتاً</span>
                              ) : user.isOnline ? (
                                <span className="text-emerald-400 font-medium">متصل الآن</span>
                              ) : (
                                <span className="text-slate-400">غير متصل</span>
                              )}
                            </td>
                            <td className="p-3 text-slate-400">
                              {new Date(user.registeredAt).toLocaleDateString('ar-EG')}
                            </td>
                            <td className="p-3 text-center">
                              <div className="flex items-center justify-center gap-1.5 flex-wrap">
                                <button
                                  type="button"
                                  onClick={() => handleClearUserChat(user.number, user.name)}
                                  className="px-2.5 py-1 rounded-lg text-[11px] font-medium bg-blue-600/20 text-blue-400 hover:bg-blue-600 hover:text-white transition flex items-center gap-1 shadow-sm"
                                  title="حذف جميع محادثات ورسائل هذا المشترك"
                                >
                                  <MessageSquare className="w-3 h-3" />
                                  <span>حذف محادثات المشترك</span>
                                </button>

                                <button
                                  onClick={() => handleToggleBan(user.number, !!user.isBanned)}
                                  className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition ${
                                    user.isBanned
                                      ? 'bg-emerald-600/20 text-emerald-400 hover:bg-emerald-600/30'
                                      : 'bg-amber-600/20 text-amber-400 hover:bg-amber-600/30'
                                  }`}
                                >
                                  {user.isBanned ? 'إلغاء الحظر' : 'حظر مؤقت'}
                                </button>

                                <button
                                  onClick={() => handlePermanentDelete(user.number, user.name)}
                                  className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-rose-600/20 text-rose-400 hover:bg-rose-600 hover:text-white transition flex items-center gap-1 shadow-sm"
                                  title="مسح المستخدم نهائياً وحظر عودته للمنصة دون إذنك"
                                >
                                  <Trash2 className="w-3 h-3" />
                                  <span>مسح نهائي وحظر العودة</span>
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Tab 3: Permanent Blacklist (المطرودون نهائياً) */}
              {activeTab === 'blacklist' && (
                <div className="space-y-4">
                  <div className="p-3.5 rounded-2xl bg-rose-950/20 border border-rose-900/30 text-xs text-rose-300 leading-relaxed flex items-center gap-2.5">
                    <AlertOctagon className="w-5 h-5 text-rose-400 shrink-0" />
                    <span>
                      <strong>قائمة المشتركين المطرودين والمحظورين نهائياً:</strong> تم مسح هؤلاء المستخدمين تماماً من المنصة، ولا يمكنهم الدخول أو العودة أو إعادة التسجيل بأرقامهم إلا إذا قمت أنت (المالك) بالضغط على زر <strong>«منح الإذن بالعودة»</strong>.
                    </span>
                  </div>

                  {blacklist.length === 0 ? (
                    <div className="p-8 text-center text-slate-500 text-xs rounded-2xl border border-slate-800">
                      لا يوجد أي مستخدم مطرود أو محظور نهائياً حالياً.
                    </div>
                  ) : (
                    <div className="overflow-x-auto rounded-2xl border border-slate-800">
                      <table className="w-full text-right text-xs">
                        <thead className="bg-slate-800/70 text-slate-400 border-b border-slate-800">
                          <tr>
                            <th className="p-3">المستخدم والرقم</th>
                            <th className="p-3">سبب الطرد</th>
                            <th className="p-3">تاريخ المسح</th>
                            <th className="p-3 text-center">إذن المالك</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800">
                          {blacklist.map((item) => (
                            <tr key={item.number} className="hover:bg-slate-800/30 transition">
                              <td className="p-3">
                                <span className="font-bold text-white block">{item.name}</span>
                                <span className="font-mono text-rose-400 text-[11px] block">{item.number}</span>
                              </td>
                              <td className="p-3 text-slate-300">{item.reason || 'مطرود نهائياً من مالك التطبيق'}</td>
                              <td className="p-3 text-slate-400 font-mono">
                                {new Date(item.bannedAt).toLocaleDateString('ar-EG')}
                              </td>
                              <td className="p-3 text-center">
                                <button
                                  onClick={() => handleRestorePermission(item.number)}
                                  className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition flex items-center gap-1.5 mx-auto active:scale-95"
                                >
                                  <UserCheck className="w-3.5 h-3.5" />
                                  منح الإذن بالعودة
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )}

              {/* Tab 3: Messages Log */}
              {activeTab === 'messages' && (
                <div className="space-y-3">
                  <div className="text-xs text-slate-400">سجل الرسائل الأخيرة في النظام:</div>
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {allMessages.slice(-40).reverse().map((msg) => (
                      <div key={msg.id} className="p-3 rounded-xl bg-slate-800/40 border border-slate-800 text-xs flex items-center justify-between">
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-mono text-blue-400 font-bold">{msg.from}</span>
                            <span className="text-slate-500">⬅</span>
                            <span className="font-mono text-purple-400 font-bold">{msg.to}</span>
                            <span className="text-[10px] text-slate-400 px-1.5 py-0.5 rounded bg-slate-800">
                              نوع: {msg.contentType}
                            </span>
                          </div>
                          <p className="text-slate-200 line-clamp-1">{msg.content || '(مرفق وسائط)'}</p>
                        </div>
                        <span className="text-[10px] text-slate-500 font-mono">
                          {new Date(msg.timestamp).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Tab 4: Call logs */}
              {activeTab === 'calls' && (
                <div className="space-y-3">
                  <div className="text-xs text-slate-400">سجل المكالمات الصوتية المنجزة:</div>
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {allCalls.length === 0 ? (
                      <div className="p-8 text-center text-slate-500 text-xs">لا توجد مكالمات صوتية بعد.</div>
                    ) : (
                      allCalls.slice(-40).reverse().map((call) => (
                        <div key={call.id} className="p-3 rounded-xl bg-slate-800/40 border border-slate-800 text-xs flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <PhoneCall className="w-4 h-4 text-blue-400" />
                            <div>
                              <span className="font-semibold text-white">{call.callerName} ({call.caller})</span>
                              <span className="text-slate-500 mx-1.5">اتصل بـ</span>
                              <span className="font-semibold text-white">{call.receiverName} ({call.receiver})</span>
                            </div>
                          </div>
                          <div className="text-left font-mono">
                            <span className="text-emerald-400 font-bold">{call.duration} ثانية</span>
                            <span className="text-[10px] text-slate-500 block">
                              {new Date(call.timestamp).toLocaleTimeString('ar-EG')}
                            </span>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}

              {/* Tab 5: Broadcast */}
              {activeTab === 'broadcast' && (
                <div className="space-y-4 max-w-lg">
                  <div className="p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 text-xs text-blue-300">
                    بث رسالة رسمية لجميع المستخدمين في تواصل 24 تظهر في محادثاتهم كإشعار عام معتمد.
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">عنوان الإشعار:</label>
                    <input
                      type="text"
                      value={broadcastTitle}
                      onChange={(e) => setBroadcastTitle(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">نص الرسالة العامة:</label>
                    <textarea
                      rows={4}
                      value={broadcastBody}
                      onChange={(e) => setBroadcastBody(e.target.value)}
                      placeholder="اكتب التنبيه أو الإعلان الذي سيظهر لجميع المستخدمين..."
                      className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-blue-500/30"
                    />
                  </div>

                  {broadcastSuccess && (
                    <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-1.5">
                      <CheckCircle className="w-4 h-4" />
                      تم إرسال الإشعار العام لجميع المستخدمين بنجاح!
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={handleSendBroadcast}
                    disabled={!broadcastBody.trim()}
                    className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-blue-600/30 transition disabled:opacity-50"
                  >
                    <Send className="w-4 h-4" />
                    إرسال البث لجميع المستخدمين
                  </button>
                </div>
              )}

              {/* Tab 6: Controls & Backup */}
              {activeTab === 'control' && (
                <div className="space-y-6 max-w-lg">
                  <div className="p-4 rounded-2xl bg-slate-800/40 border border-slate-800 space-y-3">
                    <h5 className="text-xs font-bold text-white flex items-center gap-2">
                      <Download className="w-4 h-4 text-blue-400" />
                      تصدير تقرير النظام الشامل
                    </h5>
                    <p className="text-xs text-slate-400">
                      تحميل نسخة احتياطية تتضمن جميع أرقام المستخدمين وسجلات المكالمات والرسائل.
                    </p>
                    <button
                      type="button"
                      onClick={handleExportData}
                      className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium flex items-center gap-1.5"
                    >
                      <Download className="w-4 h-4" />
                      تصدير كملف JSON
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
